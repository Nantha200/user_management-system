<?php
    include "db_connection.php";

    $sql = "SELECT * FROM registration";

    $result = $conn->query($sql);

    // Count the number of rows
    $rowCount = $result->num_rows;
?>

<html>
<head>
    <title>View page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
   
</head>
<body>
    <div class="container">

        <table class="table">
            <thead>
                <tr>
                    <th>id</th>
                    <th>invoice_no</th>
                    <th>Name</th>
                    <th>username</th>
                    <th>status</th>
                    <th>Action</th>
                </tr>
            </thead>
    
            <tbody>
                <?php 
                if ($rowCount > 0) {
                    while ($row = $result->fetch_assoc()) {
                ?>
                    <tr>
                        <td><?php echo $row['id'];?></td>
                        <td><?php echo $row['invoice_no'];?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td>      
                            <a class="btn btn-danger" href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>
                            <a class="btn btn-danger" href="update.php?id=<?php echo $row['id']; ?>">Update</a>
                        </td>
                    </tr>
            
                <?php
                    }
                } else {
                    echo "<tr><td colspan='6'>No records found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div> 
</body>
</html>
