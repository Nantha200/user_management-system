<?php
session_start();
include 'db_connection.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

   
    $sql = "SELECT * FROM registration WHERE username = '$username' ";
    
    $result = $conn->query($sql);


    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPasswordFromDatabase = $row['password'];


        if (password_verify($password, $hashedPasswordFromDatabase)) {
       
            session_regenerate_id();

            $_SESSION['username'] = $username;

            // Use die to stop script execution after header redirect
            if ($row['role'] == 'admin') {
                header("Location: admindashboard.php");
                die();
            } elseif ($row['role'] == 'user') {
                header("Location: userdashboard.php");
                die();
            } elseif ($row['role'] == 'superuser') {
                header("Location: superdashboard.php");
                die();
            }
        }
    }

    // Provide feedback for unsuccessful login
    $login_error = "Invalid username or password.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <?php if (isset($login_error)): ?>
        <p style="color: red;"><?php echo $login_error; ?></p>
    <?php endif; ?>
    <form action="" method="post">
        <label for="username">Username:</label>
        <input type="text" name="username" required>
        <br>
        <label for="password">Password:</label>
        <input type="password" name="password" required>
        <br>
        <button type="submit" name="login">Login</button>
    </form>
</body>
</html>

