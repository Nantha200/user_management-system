<?php
include('includes/header.php');
include "db_connection.php";

$sqlTotal = "SELECT * FROM registration";
$resultTotal = $conn->query($sqlTotal);


$rowCount = 0;

if ($resultTotal) {
   
    $rowCount = $resultTotal->num_rows;
} else {

    echo "Error in Total Count: " . $conn->error;
}


$sqlPending = "SELECT * FROM registration WHERE status = 'pending'";
$resultPending = $conn->query($sqlPending);


$pendingCount = 0;


if ($resultPending) {

    $pendingCount = $resultPending->num_rows;
} else {

    echo "Error in Pending Count: " . $conn->error;
}


$sqlComplete = "SELECT * FROM registration WHERE status = 'complete'";
$resultComplete = $conn->query($sqlComplete);

$completeCount = 0;


if ($resultComplete) {

    $completeCount = $resultComplete->num_rows;
} else {

    echo "Error in Complete Count: " . $conn->error;
}


$sqlOngoing = "SELECT * FROM registration WHERE status = 'ongoing'";
$resultOngoing = $conn->query($sqlOngoing);


$ongoingCount = 0;

if ($resultOngoing) {
 
    $ongoingCount = $resultOngoing->num_rows;
} else {
  
    echo "Error in Ongoing Count: " . $conn->error;
}
?>


<div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            


                <div class="row mt-4">
                    <div class="col-lg-7 position-relative z-index-2">
                        <div class="card card-plain mb-4">
                            <div class="card-body p-3">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="d-flex flex-column h-100">
                                            <h2 class="font-weight-bolder mb-0">General Statistics</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-5 col-sm-5">
                                <div class="card  mb-2">
                                    <div class="card-header p-3 pt-2">
                                        <div class="icon icon-lg icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-xl mt-n4 position-absolute">
                                            <i class="material-icons opacity-10">weekend</i>
                                        </div>
                                        <div class="text-end pt-1">
                                            <p class="text-sm mb-0 text-capitalize">NUMBER OF COUNT</p>
                                            <h4 class="mb-0"><?php echo $rowCount; ?></h4>
                                        </div>
                                    </div>

                                    <hr class="dark horizontal my-0">
                                    <div class="card-footer p-3">
                                        <p class="mb-0"></p>
                                    </div>
                                </div>


                                <div class="card  mb-2">
                                    <div class="card-header p-3 pt-2">
                                        <div class="icon icon-lg icon-shape bg-gradient-primary shadow-primary shadow text-center border-radius-xl mt-n4 position-absolute">
                                            <i class="material-icons opacity-10">leaderboard</i>
                                        </div>
                                        <div class="text-end pt-1">
                                            <p class="text-sm mb-0 text-capitalize">PENDING</p>
                                            <h4 class="mb-0"><?php echo $pendingCount; ?></h4>
                                        </div>
                                    </div>

                                    <hr class="dark horizontal my-0">
                                    <div class="card-footer p-3">
                                        <p class="mb-0"></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 col-sm-5 mt-sm-0 mt-4">
                        
                                <div class="card  mb-2">
                                    <div class="card-header p-3 pt-2 bg-transparent">
                                        <div class="icon icon-lg icon-shape bg-gradient-success shadow-success text-center border-radius-xl mt-n4 position-absolute">
                                            <i class="material-icons opacity-10">store</i>
                                        </div>
                                        <div class="text-end pt-1">
                                            <p class="text-sm mb-0 text-capitalize ">ONGOING</p>
                                            <h4 class="mb-0 "><?php echo $ongoingCount; ?></h4>
                                        </div>
                                    </div>
                                    <div class="card-footer p-3">
                                        <p class="mb-0 "></p>
                                    </div>
                                </div>

                        
                                <div class="card ">
                                    <div class="card-header p-3 pt-2 bg-transparent">
                                        <div class="icon icon-lg icon-shape bg-gradient-info shadow-info text-center border-radius-xl mt-n4 position-absolute">
                                            <i class="material-icons opacity-10">person_add</i>
                                        </div>
                                        <div class="text-end pt-1">
                                            <p class="text-sm mb-0 text-capitalize ">COMPLETE</p>
                                            <h4 class="mb-0 "><?php echo $completeCount; ?></h4>
                                        </div>
                                    </div>
                                    <hr class="horizontal my-0 dark">
                                    <div class="card-footer p-3">
                                        <p class="mb-0 "></p>
                                    </div>
                                    

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>



    <?php
    include('includes/view.php');
    ?>
</div>