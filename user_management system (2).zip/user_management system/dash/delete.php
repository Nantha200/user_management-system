<?php
    include "db_connection.php";

    if(isset($_GET['invoice_no'])){
        $invoice_no = $_GET['invoice_no'];

        $sql = "DELETE FROM `registration` WHERE `invoice_no`='$invoice_no'";

        $result = $conn->query($sql);
        if($result === TRUE){
            echo "Record deleted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
?>