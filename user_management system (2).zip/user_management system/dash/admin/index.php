<?php
include('includes/header.php');
?>
<div class="container">
    <div class="row">
    <div class="col-md-12">
        <h2>hello admin</h2>
    </div>
</div>

<?php 
include('includes/footer.php'); ?>