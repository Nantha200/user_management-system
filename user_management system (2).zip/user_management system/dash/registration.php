<?php



include 'db_connection.php';

if (isset($_POST["submit"])) {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $role = $_POST['role'];
    
    if (!empty($password)||!empty($repassword)) {
        $hashedpassword = password_hash($password, PASSWORD_DEFAULT);
        $hashedrepassword = password_hash($repassword, PASSWORD_DEFAULT);
    } 
        

        $sql = "INSERT INTO registration (name, username, password, repassword, role) 
                VALUES ('$name', '$username', '$hashedpassword', '$hashedrepassword', '$role')";

        $result = $conn->query($sql);

        if ($result === TRUE) {
            echo '';
        } else {
            echo 'Error: ' . $sql . '<br>' . $conn->error;
        }

}

?>


<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Document</title>
</head>

<body>
    <form method='post' action="" Style="width:200px; margin-left:650px; margin-top:250px;display:flex;">
        <fieldset>
            <div class="name" style="display:flex">
                <label>name:</label>
                <input type="text" name="name" placeholder="" style="margin-left:43px;"><BR>
            </div>
            <br>
            <div class="username" style="display:flex">
                <label>username:</label>
                <input type="text" name="username" placeholder="" style="margin-left:15px;"><BR>
            </div>
            <br>
            <div class="pass">
            <div class="password" style="display:flex">
                <label>password:</label>
                <input type="password" name="password" placeholder="" style="margin-left:15px;"><BR>
            </div>
            <br>

            <div class="repassword" style="display:flex">
                <label>repassword:</label>
                <input type="password" name="repassword" placeholder=""  style="margin-left:0px;"><BR>
                </div>
                <?php
                if($password != $repassword){
                    echo " Password and repassword are not matched";
                }
                ?>
            </div>
        
            </div>
           
               <br>
            <div style="display:flex">
                <label>role<label>:
                    <select option="values" name="role" id="role" style="margin-left:45px; width:170px;">
                        <option value="admin">Admin</option>
                        <option value="user">user</option>
                        <option value="superuser">superuser</option>
                    </select>
            </div>
                    <input type="submit" name="submit" value="Submit" style="margin-left:80px; margin-top:20px">
        </fieldset>
    </form>
</body>

</html>
