<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

include 'db_connection.php';

$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Superuser Dashboard</title>
</head>
<body style="margin-left:250px;">
    <h1>Welcome to the superuser Dashboard</h1>
    <h3>Superuser: <?php echo $username; ?></h3>
</body>
</html>

<?php
include 'index.php';
?>

